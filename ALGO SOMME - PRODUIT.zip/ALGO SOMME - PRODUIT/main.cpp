#include <iostream>

using namespace std;

int main() {
	int n = (0), somme(0), factorielle(1);

	cout << "Donner n :" << endl;
	cin >> n;

	for (int i(1); i <= n; i++) {
		somme += i;
		factorielle *= i;
	}

	cout << "La somme est : " << somme << endl;
	cout << "La factorielle est : " << factorielle;
}