#include <iostream>

using namespace std;

int main() {
	int type;
	float prix;

	cout << "Tapez le chiffre associer � votre statut : " << endl << "Etudiant : 1" << endl << "Enseignants : 2" << endl << "autres : " << endl;
	cin >> type;
	cout << "Indiquez le prix du livre" << endl;
	cin >> prix;

	if (type == 1) {
			cout << "le prix est de : " << prix - ((prix / 100) * 25);
	} 
	else if (type == 1) {
		cout << "le prix est de : " << prix - ((prix / 100) * 10);
	}
	else {
			cout << "le prix est de : " << prix;
		}
}