#include <iostream>

using namespace std;

int main() {
	float hauteur;
	int rebond(0);

	cout << "Hauteur de d�part de la balle en cm" << endl;
	cin >> hauteur;

	do {
		hauteur -= hauteur / 5;
		rebond++;
	} while (hauteur > 10);

	cout << "La balle fait " << rebond << " rebond avant de passer en dessous des 10 cm";
}