#include <iostream>

using namespace std;

int main() {
	int valeur_des(0), position_oie(0), taille_plateau(66);

	while (position_oie != taille_plateau) {

		while (valeur_des < 2 or valeur_des > 12) {
			cout << "Valeurs des (2 - 12)" << endl;
			cin >> valeur_des;

			if (valeur_des < 2 or valeur_des > 12) {
				cout << "La valeurs des des doit etre comprise entre 2 et 12 inclus veillez recommencer " << endl;
			}
		}

		cout << "Les des sortent : " << valeur_des << endl;
		position_oie += valeur_des;
		cout << "L'oie est en positon : " << position_oie << endl;

		if (position_oie > taille_plateau) {
			position_oie = position_oie - valeur_des - (position_oie - (taille_plateau + 2));
			cout << "Position de l'oie superieur � " << taille_plateau << " retour a la position : " << position_oie << endl;
		}
		
		if (position_oie % 9 == 0 and position_oie != 63) {
			position_oie += valeur_des;
			cout << "Oie sur un multiple de 9 : " << position_oie-valeur_des << " elle avance donc en " << position_oie << endl;
		}

		if (position_oie == 58) {
			position_oie = 0;
			cout << "Oie en position 58 retour a la case depart !"<< endl;
		}

		valeur_des = 0;
		cout << endl;

	}
	cout << "Jeux terminer !";
}