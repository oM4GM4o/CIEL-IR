#include <iostream>

using namespace std;

int main() {
	int nbLignes(0), nbEspaces(0);

	cout << "Combien de lignes ? " << endl;
	cin >> nbLignes;

	for (int n(1); n <= nbLignes; n++) {
		nbEspaces = nbLignes - n;
		for (int i(1); i <= nbEspaces; i++) {
			cout << " ";
		}
		for (int j(1); j <= 2 * n - 1; j++) {
			cout << "*";
		}
		cout << endl;
	}
}