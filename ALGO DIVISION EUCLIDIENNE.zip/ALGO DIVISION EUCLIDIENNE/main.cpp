#include <iostream>

using namespace std;

int main() {

	int a, b, quotien, reste;

	cout << "Donnez une valeurs pour a : " << endl;
	cin >> a;
	cout << "Donnez une valeurs pour b : " << endl;
	cin >> b;

	if (b != 0) {
		quotien = a / b;
		reste = a % b;

		cout << "Le quotien de " << a << " divise par " << b << " est : " << quotien << endl;
		cout << "Le reste de " << a << " divise par " << b << " est : " << reste << endl;
	}
	else {
		cout << "Division par 0 impossible, veuillez recommencer" << endl;
		main();
	}
}