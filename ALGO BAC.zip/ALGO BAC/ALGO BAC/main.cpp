#include <iostream>

using namespace std;

int main()
{
	float note (0);

	cout << "Veuillez rentrer votre note" << endl;
	cin >> note;

	if (note < 8) {
		cout << "Vous etes Ajourne(e)";
	}
	else if (note < 10)  {
		cout << "Admis au second tour";
	}
	else if (note < 12) {
		cout << "Admis, mention P";
	}
	else if (note < 14) {
		cout << "Admis, mention AB";
	}
	else if (note < 16) {
		cout << "Admis, mention B";
	}
	else if (note < 0 || note > 20) {
		cout << "Veuillez recommencer" << endl;
		main();
	}
	else {
		cout << "Admis mention TB";
	}
}