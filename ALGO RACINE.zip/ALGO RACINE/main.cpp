#include <iostream>

using namespace std;

int main() {
	float nbLu(0), resultat(0);

	do {
		cout << "Donnez un nombre positif : " << endl;
		cin >> nbLu;

		if (nbLu > 0) {
			resultat = sqrt(nbLu);
			cout << "Sa racine carre est : " << resultat;
		}
		else {
			cout << "Valeurs positives uniquement ! " << endl;
		}
	} while (nbLu != 0);
}