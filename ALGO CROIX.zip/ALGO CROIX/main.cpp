#include <iostream>

using namespace std;

int main() {
	int taille(0);

	cout << "Entrez la taille" << endl;
	cin >> taille;

	for (int ligne(1); ligne <= taille; ligne++) {
		for (int colonne(1); colonne <= taille; colonne++) {
			if (colonne == ligne || ligne + colonne - 1 == taille) {
				cout << "*";
			}
			else {
				cout << ' ';
			}
		}
		cout << endl;
	}
}