#include <iostream>

using namespace std;

int main() {
	int noteSaisie(0), noteMax(-1), noteMin(21), nbrNoteMax(0), nbrNoteMin(0);

	cout << "Donnez une note (-1 pour finir) : " << endl;
	cin >> noteSaisie;

	while (noteSaisie >= 0) {
		if (noteSaisie == noteMax) {
			nbrNoteMax++;
		}
		if (noteSaisie > noteMax) {
			noteMax = noteSaisie;
			nbrNoteMax = 1;
		}
		if (noteSaisie == noteMin) {
			nbrNoteMin += 1;
		}
		if ((noteSaisie < noteMin) && (noteSaisie >= 0)) {
			noteMin = noteSaisie;
			nbrNoteMin = 1;
		}
		cout << "Donnez une note (-1 pour finir) : " << endl;
		cin >> noteSaisie;
	}

	if (noteMax >= 0) {
		cout << "note max : " << noteMax << " attribuee " << nbrNoteMax << " fois" << endl;
		cout << "note min : " << noteMin << " attribuee " << nbrNoteMin << " fois";
	}
	else {
		cout << "Vous n'avez fourni aucune note";
	}
}