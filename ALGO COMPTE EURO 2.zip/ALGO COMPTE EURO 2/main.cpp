#include <iostream>

using namespace std;

int main() {
	int nbManiere(0);
	int somme, piece_1, piece_2, piece_3;

	cout << "Somme a calculer en centime : ";
	cin >> somme;
	cout << "type piece numeros 1 : ";
	cin >> piece_1;
	cout << "type piece numeros 2 : ";
	cin >> piece_2;
	cout << "type piece numeros 3 : ";
	cin >> piece_3;

	for (int nbP1(0); nbP1 <= somme/piece_1; nbP1++) {
		for (int nbP2(0); nbP2 <= somme/piece_2; nbP2++) {
			for (int nbP3(0); nbP3 <= somme/piece_3; nbP3++) {
				if (piece_1 * nbP1 + piece_2 * nbP2 + piece_3 * nbP3 == somme) {
					nbManiere++;
					cout << "1 Euro = ";
					if (nbP3 != 0) {
						cout << nbP3 << "x 2c ";
					}
					if (nbP2 != 0) {
						cout << nbP2 << "x 5c ";
					}
					if (nbP1 != 0) {
						cout << nbP1 << "x 10c ";
					}
					cout << endl;
				}
			}
		}
	}
	cout << "En tout il y a " << nbManiere << " de faire "<< somme <<" centimes.";
}